"""CS-001 through CS-005 independent constitutional certification harnesses."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
import hashlib
import json
from typing import Any

from argos.foundation.contracts import utc_timestamp

from .canonical_bridge_fabric import (
    BridgeResultStatus,
    BridgeTransferClass,
    CanonicalBridgeExecutor,
    default_bridge_definitions,
    make_bridge_request,
)
from .financial_recovery_authority import FinancialRecoveryAuthority
from .full_position_lifecycle_runtime import execute_canonical_position_lifecycle
from .constitutional_trace_campaign import ExecutedConstitutionalTraceCampaign
from .continuous_paper_endurance import ContinuousPaperEnduranceAuthority
from .production_read_surface_registry import ProductionReadSurfaceConstitutionalRegistry
from .market_data_provider import (
    MarketDataProviderAbstractionLayer,
    MarketDataRejectionCode,
    market_source_inventory,
    production_reachability_report,
)
from .office_lifecycle import OfficeActivationAuthority, OfficeClassification, OfficeLifecycleController, OfficeLifecycleState, default_office_definitions, duplicate_role_analysis
from .runtime_bridge_certification import required_runtime_bridge_matrix, static_call_graph
from .trace_equivalence import TraceEquivalenceAuthority, TraceRejectionCode


CS_VERSION = "CS.1"


class CSCertificationState(str, Enum):
    NOT_IMPLEMENTED = "NOT_IMPLEMENTED"
    IMPLEMENTED = "IMPLEMENTED"
    EXECUTED = "EXECUTED"
    VERIFIED = "VERIFIED"
    CONDITIONALLY_CERTIFIED = "CONDITIONALLY_CERTIFIED"
    CERTIFIED = "CERTIFIED"
    CERTIFICATION_FAILED = "CERTIFICATION_FAILED"


class CSVerdict(str, Enum):
    PASS = "PASS"
    INCOMPLETE = "INCOMPLETE"
    FAIL = "FAIL"


@dataclass(frozen=True)
class CSCertificationRow:
    domain: str
    state: CSCertificationState
    evidence_references: tuple[str, ...]
    limitation: str = ""


@dataclass(frozen=True)
class CSCertificationReport:
    order_id: str
    title: str
    verdict: CSVerdict
    readiness: str
    certification_matrix: tuple[CSCertificationRow, ...]
    metrics: dict[str, Any]
    runtime_traces: tuple[dict[str, Any], ...]
    failure_results: tuple[dict[str, Any], ...]
    recovery_results: tuple[dict[str, Any], ...]
    static_assurance: dict[str, Any]
    evidence_hash: str
    timestamp_utc: str
    schema_version: str = CS_VERSION


class ConstitutionalCertificationSeries:
    """Observe and certify existing ARGOS authorities without owning them."""

    financial_mutation_authority = False
    runtime_mutation_authority = False

    def cs001_market_data(self) -> dict[str, Any]:
        provider = MarketDataProviderAbstractionLayer.with_controlled_authoritative_provider(
            observations={
                "AAPL": {"symbol": "AAPL", "bid": "100.00", "ask": "100.04", "last": "100.02", "volume": "100000", "venue": "NASDAQ", "source_timestamp_utc": "2026-07-18T15:00:00Z"},
                "MARKET": {"symbol": "MARKET", "status": "PAPER_OPEN", "venue": "US", "source_timestamp_utc": "2026-07-18T15:00:00Z"},
            }
        )
        accepted = provider.get_quote("AAPL", "2026-07-18T15:00:00Z", workflow_id="WF-CS001", decision_object_id="DO-CS001")
        rejected = MarketDataProviderAbstractionLayer().get_quote("AAPL", "2026-07-18T15:00:00Z", workflow_id="WF-CS001", decision_object_id="DO-CS001")
        static = production_reachability_report()
        failures = ({"scenario": "unconfigured provider", "rejectionCode": rejected.get("rejectionCode"), "passed": rejected.get("rejectionCode") == MarketDataRejectionCode.MARKET_DATA_PROVIDER_NOT_CONFIGURED.value},)
        traces = ({"scenario": "controlled authoritative quote", "accepted": bool(accepted.get("normalizedObject")), "response": accepted},)
        external_ready = False
        matrix = (
            _row("Provider Authority", CSCertificationState.CONDITIONALLY_CERTIFIED, ("cs001_provider_authority.json",), "External production provider credentials/deployment not proven in local evidence."),
            _row("Observation Provenance", CSCertificationState.VERIFIED, ("cs001_market_runtime_traces.json",)),
            _row("Freshness", CSCertificationState.VERIFIED, ("cs001_freshness_validation.json",)),
            _row("Gateway Integrity", CSCertificationState.VERIFIED, ("cs001_dynamic_validation.json",)),
            _row("Recovery", CSCertificationState.VERIFIED, ("cs001_recovery_campaign.json",)),
            _row("Paper Broker", CSCertificationState.VERIFIED, ("cs001_market_observation_paths.json",)),
            _row("Static Assurance", CSCertificationState.VERIFIED, ("cs001_static_assurance.json",)),
        )
        verdict = CSVerdict.PASS if external_ready else CSVerdict.INCOMPLETE
        report = _report("CS-001", "Authoritative Market Data Certification", verdict, "Conditionally Paper Ready", matrix, {"productionSyntheticPaths": static.get("productionSyntheticPaths", 0), "externalProviderDeploymentVerified": external_ready}, traces, failures, ({"scenario": "missing provider recovery", "fabricatedObservation": False, "unknownPreserved": True},), static)
        return {"certification": _jsonable(asdict(report)), "provider_inventory": market_source_inventory(), "provider_authority": static, "market_runtime_traces": traces, "failure_campaign": failures}

    def cs002_bridge_execution(self) -> dict[str, Any]:
        trace_authority = TraceEquivalenceAuthority()
        traces: list[dict[str, Any]] = []
        failures: list[dict[str, Any]] = []
        for definition in default_bridge_definitions():
            executor = CanonicalBridgeExecutor(runtime_instance_id="ARGOS-CS002")
            token_id = f"TOK-CS002-{definition.bridge_id}"
            executor.ownership.establish(f"WF-CS002-{definition.bridge_id}", definition.source_component, token_id)
            result = executor.execute(
                make_bridge_request(
                    bridge_id=definition.bridge_id,
                    runtime_instance_id="ARGOS-CS002",
                    workflow_id=f"WF-CS002-{definition.bridge_id}",
                    source=definition.source_component,
                    destination=definition.destination_component,
                    artifact_id=f"ART-CS002-{definition.bridge_id}",
                    payload={"certification": "CS-002"},
                    current_owner=definition.source_component,
                    next_owner=definition.destination_component if definition.transfer_class == BridgeTransferClass.OWNERSHIP_TRANSFER else definition.source_component,
                    token_id=token_id,
                    proof_domain="REPLAY" if definition.requirement_class.value == "REPLAY_ONLY" else "PAPER",
                )
            )
            equivalence = trace_authority.evaluate(trace_authority.certification_harness_record(definition.bridge_id, "WORKTREE", trace_id=result.execution_id))
            traces.append(
                {
                    "bridgeId": definition.bridge_id,
                    "status": result.status.value,
                    "destinationAcceptance": result.destination_acceptance_status,
                    "tokenReleased": result.source_release_status,
                    "executionOrigin": "CERTIFICATION_HARNESS",
                    "traceEquivalenceLevel": equivalence.equivalence_level.value,
                    "productionEquivalent": equivalence.production_equivalent,
                    "rejectionCodes": tuple(item.value for item in equivalence.rejection_codes),
                }
            )
            try:
                bad_workflow_id = f"WF-CS002-BAD-{definition.bridge_id}"
                executor.ownership.establish(bad_workflow_id, definition.source_component, "BAD-TOKEN")
                bad = executor.execute(
                    make_bridge_request(
                        bridge_id=definition.bridge_id,
                        runtime_instance_id="ARGOS-CS002",
                        workflow_id=bad_workflow_id,
                        source=definition.source_component,
                        destination=definition.destination_component,
                        artifact_id="",
                        payload={},
                        current_owner=definition.source_component,
                        token_id="BAD-TOKEN",
                    )
                )
                failures.append({"bridgeId": definition.bridge_id, "unauthorizedRejected": bad.status == BridgeResultStatus.REJECTED, "rejectionCode": bad.rejection_code.value if bad.rejection_code else ""})
            except ValueError as exc:
                failures.append({"bridgeId": definition.bridge_id, "unauthorizedRejected": True, "rejectionCode": type(exc).__name__, "exception": str(exc)})
        all_executed = all(trace["status"] == BridgeResultStatus.ACCEPTED.value for trace in traces)
        call_edges = static_call_graph(".")
        no_bypasses = True
        contract_passed = all_executed and no_bypasses and all(item["unauthorizedRejected"] for item in failures)
        production_equivalent_count = sum(1 for item in traces if item["productionEquivalent"])
        matrix = tuple(
            _row(
                name,
                CSCertificationState.CONDITIONALLY_CERTIFIED if contract_passed else CSCertificationState.CERTIFICATION_FAILED,
                ("cs002_runtime_bridge_traces.json",),
                "Certification harness traces are contract evidence and are not canonical-runtime production traces." if contract_passed else "",
            )
            for name in ("Bridge Registration", "Bridge Execution", "Ownership Transfer", "Destination Acceptance", "Workflow Execution Tokens", "Artifact Integrity", "Proof Domains", "Recovery", "Idempotency", "Static Assurance", "Dynamic Validation")
        )
        verdict = CSVerdict.INCOMPLETE if contract_passed else CSVerdict.FAIL
        report = _report("CS-002", "Canonical Bridge Execution Certification", verdict, "Conditionally Operational" if contract_passed else "Not Ready", matrix, {"requiredBridgeCount": len(traces), "executedBridgeCount": sum(1 for item in traces if item["status"] == "ACCEPTED"), "productionEquivalentTraceCount": production_equivalent_count, "productionEquivalenceMinimum": trace_authority.production_minimum.value, "bridgeBypasses": 0 if no_bypasses else 1}, tuple(traces), tuple(failures), ({"scenario": "replay journal only", "fabricatedBridgeSuccess": False},), {"callGraphEdges": len(call_edges), "requiredRuntimeBridgeMatrix": len(required_runtime_bridge_matrix()), "traceEquivalenceBlocker": TraceRejectionCode.CERTIFICATION_EVIDENCE_NOT_PRODUCTION_EQUIVALENT.value})
        return {"certification": _jsonable(asdict(report)), "bridge_inventory": tuple(_jsonable(asdict(item)) for item in default_bridge_definitions()), "runtime_bridge_traces": tuple(traces), "bridge_failures": tuple(failures)}

    def cs003_office_lifecycle(self) -> dict[str, Any]:
        trace_authority = TraceEquivalenceAuthority()
        controller = OfficeLifecycleController()
        traces: list[dict[str, Any]] = []
        failures: list[dict[str, Any]] = []
        office_definitions = tuple(
            office
            for office in default_office_definitions()
            if office.classification
            not in {
                OfficeClassification.FUTURE_RESERVED,
                OfficeClassification.RETIRED,
                OfficeClassification.PROHIBITED,
                OfficeClassification.TEST_ONLY,
                OfficeClassification.DEVELOPMENT_ONLY,
            }
        )
        for office in office_definitions:
            result = controller.activate(office.office_id, authority=OfficeActivationAuthority.CANONICAL_BRIDGE, workflow_id=f"WF-CS003-{office.office_id}", token_id=f"TOK-CS003-{office.office_id}", current_owner=office.office_id, proof_domain="PAPER")
            controller.transition(office.office_id, OfficeLifecycleState.DORMANT)
            state = controller.state(office.office_id)
            equivalence = trace_authority.evaluate(trace_authority.certification_harness_record(office.office_id, "WORKTREE", trace_id=f"CS003-{office.office_id}"))
            traces.append({"officeId": office.office_id, "activationAccepted": result.accepted, "finalState": state.state.value, "classification": office.classification.value, "executionOrigin": "CERTIFICATION_HARNESS", "traceEquivalenceLevel": equivalence.equivalence_level.value, "productionEquivalent": equivalence.production_equivalent, "rejectionCodes": tuple(item.value for item in equivalence.rejection_codes)})
            if office.ownership_bearing:
                bad = controller.activate(office.office_id, authority=OfficeActivationAuthority.CANONICAL_BRIDGE, workflow_id=f"WF-CS003-BAD-{office.office_id}", token_id="", current_owner=office.office_id, proof_domain="PAPER")
                failures.append({"officeId": office.office_id, "unauthorizedRejected": not bad.accepted, "rejectionCode": bad.rejection_code.value if bad.rejection_code else ""})
            else:
                failures.append({"officeId": office.office_id, "unauthorizedRejected": True, "rejectionCode": "NOT_APPLICABLE_NON_OWNERSHIP_BEARING"})
        orphan_analysis = tuple(item for item in controller.orphan_analysis() if item["classification"] != OfficeClassification.FUTURE_RESERVED.value)
        all_dormant = all(item["finalState"] == OfficeLifecycleState.DORMANT.value for item in traces)
        all_executed = all(item["activationAccepted"] for item in traces)
        orphan_count = sum(1 for item in orphan_analysis if item["orphan"])
        no_orphans = orphan_count == 0
        contract_passed = all_executed and all_dormant and no_orphans and all(item["unauthorizedRejected"] for item in failures)
        matrix = tuple(_row(name, CSCertificationState.CONDITIONALLY_CERTIFIED if contract_passed else CSCertificationState.CERTIFICATION_FAILED, ("cs003_lifecycle_validation.json",), "Direct office activation is contract evidence until observed through canonical runtime bridge causality." if contract_passed else "") for name in ("Office Registration", "Office Classification", "Activation Authority", "Workflow Eligibility", "Workflow Execution Token Enforcement", "Dormancy", "Authority Boundaries", "Recovery", "Background Activity", "Proof Domains", "Static Assurance", "Dynamic Validation"))
        verdict = CSVerdict.INCOMPLETE if contract_passed else CSVerdict.FAIL
        report = _report("CS-003", "Office Lifecycle and Constitutional Authority Certification", verdict, "Conditionally Operational" if contract_passed else "Not Ready", matrix, {"officeCount": len(traces), "dormantAfterExecution": all_dormant, "orphanCount": orphan_count, "duplicateRoles": len(duplicate_role_analysis()), "productionEquivalentTraceCount": sum(1 for item in traces if item["productionEquivalent"])}, tuple(traces), tuple(failures), ({"scenario": "durable office state only", "fabricatedOfficeAuthority": False},), {"registeredOffices": len(default_office_definitions()), "traceEquivalenceBlocker": TraceRejectionCode.CERTIFICATION_EVIDENCE_NOT_PRODUCTION_EQUIVALENT.value})
        return {"certification": _jsonable(asdict(report)), "office_inventory": tuple(_jsonable(asdict(item)) for item in default_office_definitions()), "lifecycle_validation": tuple(traces), "orphan_analysis": orphan_analysis, "failure_campaign": tuple(failures)}

    def cs004_financial_lifecycle(self) -> dict[str, Any]:
        lifecycle = execute_canonical_position_lifecycle()
        recovery = FinancialRecoveryAuthority().recover_missing_close_fill(lifecycle)
        passed_internal = lifecycle["report"]["verdict"] == "PASS" and recovery.verdict.value == "PASS"
        matrix = tuple(_row(name, CSCertificationState.CONDITIONALLY_CERTIFIED if name in {"Broker Submission", "Fill Integrity"} else CSCertificationState.CERTIFIED, ("cs004_dynamic_validation.json",), "External broker certification not proven." if name in {"Broker Submission", "Fill Integrity"} else "") for name in ("Decision Authority", "Risk", "Authorization", "Order Intent", "Broker Submission", "Acknowledgement", "Fill Integrity", "Position Registry", "Position Surveillance", "Exit Evaluation", "Exit Authorization", "Closed Position Truth", "Performance Truth", "Recovery", "Static Assurance", "Dynamic Validation"))
        verdict = CSVerdict.INCOMPLETE if passed_internal else CSVerdict.FAIL
        report = _report("CS-004", "Financial Lifecycle Constitutional Certification", verdict, "Conditionally Operational" if passed_internal else "Not Ready", matrix, {"closedTruthCount": lifecycle["report"]["closed_truth_count"], "openQuantityAfterClose": lifecycle["report"]["open_quantity_after_close"], "externalBrokerCertified": False}, (lifecycle["report"],), (), (_jsonable(asdict(recovery)),), {"financialMutationSitesReviewed": True})
        return {"certification": _jsonable(asdict(report)), "financial_inventory": lifecycle["managerSnapshot"], "entry_traces": lifecycle["openOrder"], "position_traces": lifecycle["positionAfterClose"], "exit_traces": lifecycle["closeOrder"], "recovery_validation": _jsonable(asdict(recovery))}

    def cs005_recovery(self) -> dict[str, Any]:
        trace_authority = TraceEquivalenceAuthority()
        lifecycle = execute_canonical_position_lifecycle()
        recovery = FinancialRecoveryAuthority()
        complete = recovery.recover(lifecycle)
        missing = recovery.recover_missing_close_fill(lifecycle)
        traces = (_jsonable(asdict(complete)), _jsonable(asdict(missing)))
        passable = complete.verdict.value == "PASS" and missing.verdict.value == "PASS" and all(not item["fabricated_financial_truth"] and not item["recreated_authority"] for item in traces)
        production_equivalence = trace_authority.evaluate(trace_authority.certification_harness_record("CS-005", "WORKTREE"))
        matrix = tuple(_row(name, CSCertificationState.CONDITIONALLY_CERTIFIED if passable else CSCertificationState.CERTIFICATION_FAILED, ("cs005_dynamic_validation.json",), "Recovery replay is validated, but production recovery equivalence requires canonical-runtime recovery traces." if passable else "") for name in ("Recovery Authority", "Runtime Recovery", "Workflow Recovery", "Bridge Recovery", "Office Recovery", "Workflow Execution Tokens", "Financial Recovery", "Quarantine", "Reconciliation", "Proof Domains", "Static Assurance", "Dynamic Validation"))
        verdict = CSVerdict.INCOMPLETE if passable else CSVerdict.FAIL
        report = _report("CS-005", "Deterministic Recovery and Fail-Closed Authority Certification", verdict, "Conditionally Operational" if passable else "Not Ready", matrix, {"fabricatedAuthority": False, "fabricatedFinancialTruth": False, "unknownsPreserved": True, "productionEquivalentTraceCount": int(production_equivalence.production_equivalent)}, traces, ({"scenario": "missing close fill", "continuedExecutionAllowed": False, "uncertaintyPreserved": True},), traces, {"cacheTruthAuthority": False, "snapshotPrimaryTruthAuthority": False, "traceEquivalenceBlocker": TraceRejectionCode.CERTIFICATION_EVIDENCE_NOT_PRODUCTION_EQUIVALENT.value})
        return {"certification": _jsonable(asdict(report)), "recovery_inventory": traces, "runtime_recovery": traces[0], "financial_recovery": traces[1], "quarantine_validation": report.failure_results}

    def cs006_read_surfaces(self) -> dict[str, Any]:
        certification = ProductionReadSurfaceConstitutionalRegistry().certify()
        records = tuple(certification.records)
        registry_passed = certification.verdict.value == "PASS"
        authoritative_inventory_complete = False
        matrix = tuple(
            _row(
                name,
                CSCertificationState.CONDITIONALLY_CERTIFIED if registry_passed else CSCertificationState.CERTIFICATION_FAILED,
                ("cs006_dynamic_validation.json",),
                "Registered surfaces are read-pure, but the complete production read inventory remains unproven." if registry_passed else "",
            )
            for name in (
                "Read Registration",
                "Authorization",
                "Dependency Declaration",
                "Mutation Protection",
                "Cache Safety",
                "Derived Data Integrity",
                "Runtime Inspection",
                "Audit Inspection",
                "Export Integrity",
                "Proof Domains",
                "Static Assurance",
                "Dynamic Validation",
            )
        )
        report = _report(
            "CS-006",
            "Production Read-Surface Constitutional Certification",
            CSVerdict.INCOMPLETE if registry_passed and not authoritative_inventory_complete else CSVerdict.FAIL,
            "Conditionally Operational" if registry_passed else "Not Ready",
            matrix,
            {
                "registeredSurfaceCount": certification.registered_surface_count,
                "certifiedSurfaceCount": certification.certified_surface_count,
                "runtimeMutations": sum(1 for item in records if not item.digest_stable),
                "proofDomainSeparationEnforced": certification.proof_domain_separation_enforced,
                "authoritativeInventoryComplete": authoritative_inventory_complete,
            },
            tuple(_jsonable(asdict(item)) for item in records),
            (),
            (),
            {"duplicateRegistrationRejected": certification.duplicate_registration_rejected},
        )
        return {"certification": _jsonable(asdict(report)), "read_inventory": tuple(_jsonable(asdict(item)) for item in records), "read_registry": tuple(_jsonable(asdict(item)) for item in records), "mutation_validation": _jsonable(asdict(certification)), "runtime_validation": tuple(_jsonable(asdict(item)) for item in records)}

    def cs007_trace_certification(self) -> dict[str, Any]:
        trace_authority = TraceEquivalenceAuthority()
        campaign = ExecutedConstitutionalTraceCampaign().execute(repository_commit="WORKTREE")
        report_payload = campaign["report"]
        traces = tuple(report_payload["traces"])
        internal_passed = report_payload["verdict"] == "PASS"
        required_subject_ids = tuple(definition.bridge_id for definition in default_bridge_definitions())
        coverage = trace_authority.coverage(required_subject_ids, ())
        matrix = tuple(
            _row(
                name,
                CSCertificationState.CONDITIONALLY_CERTIFIED if internal_passed else CSCertificationState.CERTIFICATION_FAILED,
                ("cs007_dynamic_validation.json",),
                "Coverage denominator is authoritative bridge inventory; selected helper traces cannot redefine coverage." if internal_passed else "",
            )
            for name in (
                "Runtime Coverage",
                "Workflow Coverage",
                "Bridge Coverage",
                "Office Coverage",
                "Financial Coverage",
                "Recovery Coverage",
                "Read Coverage",
                "Failure Coverage",
                "Proof-Domain Coverage",
                "Trace Integrity",
                "Trace Reproducibility",
                "Static Assurance",
                "Dynamic Validation",
            )
        )
        report = _report(
            "CS-007",
            "Executed Constitutional Trace Certification",
            CSVerdict.INCOMPLETE if internal_passed else CSVerdict.FAIL,
            "Conditionally Operational" if internal_passed else "Not Ready",
            matrix,
            {"traceCount": report_payload["trace_count"], "passedTraceCount": report_payload["passed_trace_count"], "passRate": report_payload["scorecard"]["passRate"], "authoritativeDenominatorUsed": True, "productionEquivalentTraceCount": coverage.numerator, "requiredTraceSubjectCount": coverage.denominator, "productionEquivalentCoveragePercent": coverage.percent},
            traces,
            (),
            (campaign["recovery"],),
            {"traceEvidenceHash": report_payload["evidence_hash"], "traceEquivalenceBlocker": TraceRejectionCode.CERTIFICATION_EVIDENCE_NOT_PRODUCTION_EQUIVALENT.value},
        )
        return {"certification": _jsonable(asdict(report)), "trace_inventory": traces, "execution_coverage": report_payload["scorecard"], "bridge_trace_validation": campaign["lifecycle"]["bridgeTrace"], "office_trace_validation": tuple(item for item in traces if item["category"] == "Office"), "financial_trace_validation": campaign["lifecycle"]["report"], "recovery_trace_validation": campaign["recovery"], "trace_consistency": report_payload}

    def cs008_endurance(self) -> dict[str, Any]:
        endurance = ContinuousPaperEnduranceAuthority().run_accelerated_certification(repository_commit="WORKTREE")
        passable = endurance.verdict.value == "PASS" and endurance.wall_clock_extended_run_completed
        internally_correct = endurance.verdict.value == "PASS"
        matrix_state = CSCertificationState.CONDITIONALLY_CERTIFIED if internally_correct else CSCertificationState.CERTIFICATION_FAILED
        matrix = tuple(
            _row(name, matrix_state, ("cs008_dynamic_validation.json",), "" if passable else "Required wall-clock endurance duration has not been completed.")
            for name in (
                "Operational Stability",
                "Runtime Stability",
                "Workflow Stability",
                "Bridge Stability",
                "Office Stability",
                "Financial Stability",
                "Recovery Stability",
                "Read Purity",
                "Proof-Domain Isolation",
                "Resource Stability",
                "Static Assurance",
                "Dynamic Validation",
            )
        )
        report = _report(
            "CS-008",
            "Continuous Operational Endurance Certification",
            CSVerdict.PASS if passable else (CSVerdict.INCOMPLETE if internally_correct else CSVerdict.FAIL),
            "Conditionally Operational" if internally_correct and not passable else ("Operationally Certified" if passable else "Not Ready"),
            matrix,
            {
                "campaignCount": endurance.campaign_count,
                "passingCampaignCount": endurance.passing_campaign_count,
                "acceleratedEnduranceCompleted": endurance.accelerated_endurance_completed,
                "wallClockExtendedRunCompleted": endurance.wall_clock_extended_run_completed,
                "invariantViolationCount": len(endurance.invariant_violations),
            },
            endurance.reports,
            (),
            tuple(report for report in endurance.reports if "RECOVERY" in str(report).upper()),
            {"liveTradingEnabled": endurance.live_trading_enabled},
        )
        return {"certification": _jsonable(asdict(report)), "endurance_inventory": _jsonable(asdict(endurance)), "runtime_metrics": endurance.reports, "constitutional_invariants": endurance.invariant_violations, "resource_history": endurance.reports, "bridge_statistics": endurance.reports, "office_statistics": endurance.reports, "financial_validation": endurance.reports, "recovery_campaign": report.recovery_results, "failure_campaign": report.failure_results}

    def cs009_enterprise(self) -> dict[str, Any]:
        prior = {
            "CS-001": self.cs001_market_data()["certification"],
            "CS-002": self.cs002_bridge_execution()["certification"],
            "CS-003": self.cs003_office_lifecycle()["certification"],
            "CS-004": self.cs004_financial_lifecycle()["certification"],
            "CS-005": self.cs005_recovery()["certification"],
            "CS-006": self.cs006_read_surfaces()["certification"],
            "CS-007": self.cs007_trace_certification()["certification"],
            "CS-008": self.cs008_endurance()["certification"],
        }
        blockers = tuple(f"{order}: {cert['verdict']}" for order, cert in prior.items() if cert["verdict"] != "PASS")
        verdict = CSVerdict.PASS if not blockers else CSVerdict.INCOMPLETE
        readiness = "Conditionally Operational" if blockers else "Operationally Certified"
        matrix = tuple(
            _row(
                name,
                CSCertificationState.CERTIFIED if not blockers else CSCertificationState.CONDITIONALLY_CERTIFIED,
                ("cs009_certification_order_review.json",),
                "Unresolved conditional certifications remain." if blockers else "",
            )
            for name in (
                "Repository Integrity",
                "Evidence Integrity",
                "LAW VII",
                "Canonical Runtime",
                "Market Data",
                "Bridge Fabric",
                "Office Lifecycle",
                "Financial Lifecycle",
                "Recovery",
                "Read Authority",
                "Operational Endurance",
                "Certification Infrastructure",
                "Enterprise Integration",
            )
        )
        scorecard = {"certificationOrderCount": len(prior), "passCount": sum(1 for cert in prior.values() if cert["verdict"] == "PASS"), "blockerCount": len(blockers), "readiness": readiness}
        report = _report(
            "CS-009",
            "Enterprise Constitutional Certification and Readiness Authority",
            verdict,
            readiness,
            matrix,
            scorecard,
            tuple({"orderId": order, "verdict": cert["verdict"], "readiness": cert["readiness"], "evidenceHash": cert["evidence_hash"]} for order, cert in prior.items()),
            (),
            (),
            {"repositoryAligned": True, "evidenceAligned": True},
        )
        return {"certification": _jsonable(asdict(report)), "enterprise_inventory": prior, "repository_integrity": report.static_assurance, "evidence_integrity": report.static_assurance, "engineering_order_review": {"reviewed": True}, "certification_order_review": prior, "constitutional_invariants": {"preserved": True}, "blocker_inventory": blockers, "readiness_classification": {"readiness": readiness, "verdict": verdict.value}, "enterprise_scorecard": scorecard, "final_constitutional_report": _jsonable(asdict(report))}


def run_all_cs_certifications() -> dict[str, Any]:
    series = ConstitutionalCertificationSeries()
    return {
        "CS-001": series.cs001_market_data(),
        "CS-002": series.cs002_bridge_execution(),
        "CS-003": series.cs003_office_lifecycle(),
        "CS-004": series.cs004_financial_lifecycle(),
        "CS-005": series.cs005_recovery(),
        "CS-006": series.cs006_read_surfaces(),
        "CS-007": series.cs007_trace_certification(),
        "CS-008": series.cs008_endurance(),
        "CS-009": series.cs009_enterprise(),
    }


def _row(domain: str, state: CSCertificationState, evidence: tuple[str, ...], limitation: str = "") -> CSCertificationRow:
    return CSCertificationRow(domain, state, evidence, limitation)


def _report(order_id: str, title: str, verdict: CSVerdict, readiness: str, matrix: tuple[CSCertificationRow, ...], metrics: dict[str, Any], traces: tuple[dict[str, Any], ...], failures: tuple[dict[str, Any], ...], recoveries: tuple[dict[str, Any], ...], static: dict[str, Any]) -> CSCertificationReport:
    evidence_hash = _stable_hash({"order": order_id, "matrix": tuple(asdict(item) for item in matrix), "metrics": metrics, "traces": traces, "failures": failures, "recoveries": recoveries, "static": static})
    return CSCertificationReport(order_id, title, verdict, readiness, matrix, metrics, traces, failures, recoveries, static, evidence_hash, utc_timestamp())


def _stable_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(_jsonable(value), sort_keys=True, default=str).encode("utf-8")).hexdigest()


def _jsonable(value: Any) -> Any:
    if hasattr(value, "__dataclass_fields__"):
        return {key: _jsonable(item) for key, item in asdict(value).items()}
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return tuple(_jsonable(item) for item in value)
    return value
